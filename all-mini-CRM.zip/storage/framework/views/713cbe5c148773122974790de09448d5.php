<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $status = $status ?? 'warm';
    $classes = [
        'hot' => 'bg-red-100 text-red-800',
        'warm' => 'bg-indigo-100 text-indigo-800', // Indigo theme
        'cold' => 'bg-gray-100 text-gray-800',
    ][$status] ?? 'bg-gray-100 text-gray-800';
?>

<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($classes); ?>">
    <?php echo e(ucfirst($status)); ?>

</span>
<?php /**PATH /home/chetan/Desktop/mini-crm/resources/views/components/lead-badge.blade.php ENDPATH**/ ?>